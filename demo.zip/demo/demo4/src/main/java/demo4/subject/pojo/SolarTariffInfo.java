package demo4.subject.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SolarTariffInfo {
    private Integer id;
    private String hsCode;
    private String description;
    private String cnCode;
    private String rateType;
    private String baseRate;
    private String additionalRate;
    private String effectiveDate;
}

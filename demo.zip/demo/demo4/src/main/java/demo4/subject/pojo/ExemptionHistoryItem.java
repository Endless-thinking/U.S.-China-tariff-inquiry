package demo4.subject.pojo;

import lombok.Data;

@Data
public class ExemptionHistoryItem {
    private String period;
    private String status;
}

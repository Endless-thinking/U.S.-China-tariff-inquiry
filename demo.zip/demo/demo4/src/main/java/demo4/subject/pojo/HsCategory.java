package demo4.subject.pojo;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HsCategory {
    private String hsCode;
    private String name;
    private String category;
}

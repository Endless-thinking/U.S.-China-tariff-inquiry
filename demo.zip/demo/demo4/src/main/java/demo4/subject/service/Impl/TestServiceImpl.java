package demo4.subject.service.Impl;

import demo4.subject.dto.TariffDetailDTO;
import demo4.subject.mapper.ExemptionHistoryItemMapper;
import demo4.subject.mapper.RateHistoryItemMapper;
import demo4.subject.mapper.SolarTariffInfoMapper;
import demo4.subject.pojo.ExemptionHistoryItem;
import demo4.subject.pojo.HsCategory;
import demo4.subject.pojo.RateHistoryItem;
import demo4.subject.pojo.SolarTariffInfo;
import jakarta.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import demo4.subject.service.TestService;

import java.util.List;

@Service
public class TestServiceImpl implements TestService {

    @Resource
    private SolarTariffInfoMapper solarTariffInfoMapper;

    @Resource
    private RateHistoryItemMapper rateHistoryItemMapper;

    @Resource
    private ExemptionHistoryItemMapper exemptionHistoryItemMapper;

    @Override
    public TariffDetailDTO tariffDetail(HsCategory hsCategory) {
        SolarTariffInfo solarTariffInfo = solarTariffInfoMapper.getDetail(hsCategory);
        if(solarTariffInfo == null) {
            return null;
        }
        List <RateHistoryItem>listRHI = rateHistoryItemMapper.getDetail(solarTariffInfo.getId());
        List<ExemptionHistoryItem>listEHI = exemptionHistoryItemMapper.getDetail(solarTariffInfo.getId());

        TariffDetailDTO tariffDetailDTO = new TariffDetailDTO();
        BeanUtils.copyProperties(solarTariffInfo, tariffDetailDTO);
        tariffDetailDTO.setRateHistory(listRHI);
        tariffDetailDTO.setExemptionHistory(listEHI);
        return tariffDetailDTO;
    }
}

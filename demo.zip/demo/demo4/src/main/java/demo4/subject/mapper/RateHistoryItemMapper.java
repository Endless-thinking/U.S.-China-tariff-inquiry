package demo4.subject.mapper;

import demo4.subject.pojo.RateHistoryItem;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface RateHistoryItemMapper {

    List<RateHistoryItem> getDetail(Integer SolarTariffInfoId);
}

package demo4.subject.pojo;

import lombok.Data;

@Data
public class RateType {
    private Integer rateTypeId;
    private String rateTypeName;
}

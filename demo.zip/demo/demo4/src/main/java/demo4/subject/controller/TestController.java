package demo4.subject.controller;

import demo4.subject.dto.TariffDetailDTO;
import demo4.subject.pojo.HsCategory;
import demo4.subject.pojo.TariffRate;
import demo4.subject.service.TestService;
import demo4.subject.utils.Result;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TestController {
    @Resource
    private TestService testService;

    @PostMapping("/tariff-detail")
    public Result tariffDetail(@RequestBody HsCategory hsCategory) {
        TariffDetailDTO tariffDetailDTO = testService.tariffDetail(hsCategory);
        return Result.ok(tariffDetailDTO);
    }
}

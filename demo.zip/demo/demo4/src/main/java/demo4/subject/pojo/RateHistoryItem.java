package demo4.subject.pojo;

import lombok.*;
import lombok.experimental.Accessors;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RateHistoryItem {
    private String historyDate;
    private String type;
    private String baseRate;
    private String additionalDuty;
    private String policy;
}

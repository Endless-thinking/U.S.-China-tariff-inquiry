package demo4.subject.mapper;

import demo4.subject.pojo.ExemptionHistoryItem;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ExemptionHistoryItemMapper {
    List<ExemptionHistoryItem> getDetail(Integer solarTariffId);
}

package demo4.subject.dto;

import demo4.subject.pojo.ChartData;
import demo4.subject.pojo.ExemptionHistoryItem;
import demo4.subject.pojo.RateHistoryItem;
import lombok.Data;
import java.util.List;

@Data
public class TariffDetailDTO {
    private String hsCode;
    private String description;
    private String cnCode;
    private String rateType;
    private String baseRate;
    private String additionalRate;
    private String effectiveDate;
    private List<RateHistoryItem> rateHistory;
    private List<ExemptionHistoryItem> exemptionHistory;
    private ChartData chartData;
}

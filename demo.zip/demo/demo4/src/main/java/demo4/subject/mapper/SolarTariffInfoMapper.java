package demo4.subject.mapper;

import demo4.subject.pojo.HsCategory;
import demo4.subject.pojo.SolarTariffInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SolarTariffInfoMapper {

    SolarTariffInfo getDetail(HsCategory hsCategory);
}

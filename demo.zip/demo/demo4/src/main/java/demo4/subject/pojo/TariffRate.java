package demo4.subject.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TariffRate {
    private Integer rateId;
    private String hsCode;
    private Integer countryId;
    private Integer rateTypeId;
    private Integer directionId;
    private BigDecimal rateValue;
}

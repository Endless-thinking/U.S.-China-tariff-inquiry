package demo4.subject.pojo;

import lombok.Data;
import java.util.List;

@Data
public class Dataset {
    private String label;
    private List<Integer> data;
}


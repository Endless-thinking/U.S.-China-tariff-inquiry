package demo4.subject.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TestMapper {
}

package demo4.subject.pojo;

import lombok.Data;
import java.util.List;

@Data
public class ImportVolume {
    private List<String> labels;
    private List<Dataset> datasets;
}

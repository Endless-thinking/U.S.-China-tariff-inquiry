package demo4.subject.pojo;

import lombok.Data;

@Data
public class ChartData {
    private RateTrend rateTrend;
    private ImportVolume importVolume;
}

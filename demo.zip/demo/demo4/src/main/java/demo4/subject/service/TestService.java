package demo4.subject.service;


import demo4.subject.dto.TariffDetailDTO;
import demo4.subject.pojo.HsCategory;

public interface TestService {
    TariffDetailDTO tariffDetail(HsCategory hsCategory);
}

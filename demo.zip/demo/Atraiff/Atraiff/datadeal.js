// 导航链接平滑滚动
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 70, // 减去导航栏高度
        behavior: 'smooth'
      });
    }
  });
});


// 窗口大小变化时重绘图表
const charts = [];

function initResponsiveCharts() {
  const trendChart = initTrendChart();
  const volumeChart = initVolumeChart();
  charts.push(trendChart, volumeChart);

  window.addEventListener('resize', function() {
    charts.forEach(chart => {
      chart.resize();
    });
  });
}
